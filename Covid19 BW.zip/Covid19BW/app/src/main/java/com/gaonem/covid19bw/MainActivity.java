package com.gaonem.covid19bw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //implementing firebase analytics
        FirebaseAnalytics.getInstance(this);
        BottomNavigationView navigation = findViewById(R.id.nav_view);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


        Button btn_precautions = findViewById(R.id.Btn_Precautions);
        Button btn_Helpline = findViewById(R.id.Btn_Helpline);


        //starting precaution activity
        btn_precautions.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, PrecautionsActivity.class));
            //setting up slide up animation
            overridePendingTransition(R.anim.slide_up, R.anim.no_animation);

        });

        //starting precaution activity
        btn_Helpline.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,HelpLineActivity.class));



        });
    }



    //handling bottom navigation
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = item -> {
        switch (item.getItemId()) {
            case R.id.navigation_home:
                return true;
            case R.id.navigation_stats:
                startActivity(new Intent(MainActivity.this, StatsActivity.class));
                overridePendingTransition(R.anim.slide_up, R.anim.no_animation);
                finish();


                return true;
            case R.id.navigation_settings:
                startActivity(new Intent(MainActivity.this, SettingMoreActivity.class));
                finish();



        }
        return false;
    };



}

